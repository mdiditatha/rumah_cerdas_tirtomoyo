<!doctype html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Member Baru</title>
</head>
<body>
<h3>Pendaftaran Member Anggota Baru</h3>
{{--<p><img src="book_image.jpg" style="height:350px"></img></p>--}}
<p>Nama Member: {{ $data->name }}</p>
<p>Email Member: {{ $data->email }}</p>
<p>Mohon Untuk DiVerifikasi Akun di website Rumah Cerdas Cendikia</p>
</body>
</html>