<h1>Syarat dan ketentuan</h1>
<ol>
    <li>Harus Warga Tirtomoyo</li>
</ol>
<a href="{{ route('login') }}">Back</a>